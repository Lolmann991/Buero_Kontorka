// Стол, мониторы-слоты, часы Sony, стартовый экран и подсказка поворота.
// Только рисует и шлёт намерения. Игровой логики здесь нет.

import * as audio from '../audio.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

// ---------- часы Sony ----------
// Всё в координатах фото (1672x941). Параметры подобраны по цифрам «12:02» на снимке.
const CLOCK = {
  rotate: 5.25,   // базовая линия идёт вниз вправо
  skew: 5.5,      // наклон цифр (курсив)
  w: 23, h: 41.5, t: 3.1, gap: 0.2, // размеры цифры и толщина сегмента
  cells: [        // левый нижний угол каждой ячейки: d1 d2 d3 d4
    [1428.0, 714.2],
    [1458.6, 717.0],
    [1500.6, 720.0],
    [1532.6, 723.0],
  ],
  colon: [1491.0, 720.0],
};

// ---------- мониторы ----------
// Экран каждого монитора на фото это четырёхугольник (мониторы стоят чуть V-образно).
// Холст 640x376 растягивается на него матрицей matrix3d (перспективное преобразование).
// Углы (в px фото 1672x941): левый верх, правый верх, правый низ, левый низ.
export const PHOTO_W = 1672;
const CLOCK_GLITCH_SEC = 3;   // сколько секунд минуты на часах видны в глюке 3:33
export const MONITOR_SIZE = [640, 376];
export const MONITOR_QUADS = {
  left:  [[55.3, 138.6], [832.0, 149.4], [832.0, 593.3], [69.0, 601.6]],
  right: [[847.0, 149.5], [1614.2, 139.0], [1607.0, 600.7], [847.0, 593.6]],
};

// Прямоугольник w x h -> четырёхугольник quad, масштаб k (px сцены на px фото).
// Возвращает 16 чисел для CSS matrix3d (по столбцам).
export function monitorMatrix(quad, w, h, k = 1) {
  const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = quad;
  const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3;
  const dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
  const den = dx1 * dy2 - dx2 * dy1;
  const g = (dx3 * dy2 - dx2 * dy3) / den;
  const hh = (dx1 * dy3 - dx3 * dy1) / den;
  const a = x1 - x0 + g * x1, b = x3 - x0 + hh * x3, c = x0;
  const d = y1 - y0 + g * y1, e = y3 - y0 + hh * y3, f = y0;
  // единичный квадрат -> холст w x h, затем масштаб k для координат на выходе
  return [
    (k * a) / w, (k * d) / w, 0, g / w,
    (k * b) / h, (k * e) / h, 0, hh / h,
    0, 0, 1, 0,
    k * c, k * f, 0, 1,
  ];
}

function layoutMonitors() {
  if (!els.stage) return;
  const k = els.stage.clientWidth / PHOTO_W;
  if (!k) return;
  const [w, h] = MONITOR_SIZE;
  for (const [side, node] of [['left', els.monLeft], ['right', els.monRight]]) {
    node.style.transform = `matrix3d(${monitorMatrix(MONITOR_QUADS[side], w, h, k).join(',')})`;
    node.classList.add('is-ready');
  }
}

const DIGIT_SEGMENTS = {
  '0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc',
  '5': 'afgcd', '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg',
  A: 'abcefg', M: 'abcefm',   // m: добавочный центральный сегмент, нужен для буквы M
};

// Шесть точек сегмента в локальных координатах (y вверх) -> строка для SVG (y вниз).
function segmentPoints() {
  const { w, h, t, gap: g } = CLOCK;
  const c = t / 2;
  const L = c, R = w - c, B = c, M = h / 2, T = h - c;
  const horiz = (y) => [
    [L + c + g, y], [L + 2 * c + g, y + c], [R - 2 * c - g, y + c],
    [R - c - g, y], [R - 2 * c - g, y - c], [L + 2 * c + g, y - c],
  ];
  const vert = (x, ya, yb) => [
    [x, yb - c - g], [x + c, yb - 2 * c - g], [x + c, ya + 2 * c + g],
    [x, ya + c + g], [x - c, ya + 2 * c + g], [x - c, yb - 2 * c - g],
  ];
  const str = (pts) => pts.map(([x, y]) => `${x.toFixed(2)},${(-y).toFixed(2)}`).join(' ');
  return {
    a: str(horiz(T)), g: str(horiz(M)), d: str(horiz(B)),
    f: str(vert(L, M, T)), b: str(vert(R, M, T)),
    e: str(vert(L, B, M)), c: str(vert(R, B, M)),
    m: str(vert((L + R) / 2, M, T)),
  };
}

function svgEl(tag, attrs, parent) {
  const e = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
  if (parent) parent.appendChild(e);
  return e;
}

function buildClock(parent) {
  const svg = svgEl('svg', { viewBox: '0 0 1672 941', preserveAspectRatio: 'none', class: 'clock-svg' }, parent);

  const defs = svgEl('defs', {}, svg);
  const filter = svgEl('filter', { id: 'clock-glow', x: '-20%', y: '-40%', width: '140%', height: '180%' }, defs);
  svgEl('feGaussianBlur', { stdDeviation: '1.8', result: 'blur' }, filter);
  const merge = svgEl('feMerge', {}, filter);
  svgEl('feMergeNode', { in: 'blur' }, merge);
  svgEl('feMergeNode', { in: 'SourceGraphic' }, merge);

  const root = svgEl('g', { filter: 'url(#clock-glow)' }, svg);
  const pts = segmentPoints();
  const { rotate, skew } = CLOCK;
  const cells = CLOCK.cells.map(([x, y]) => {
    const g = svgEl('g', { transform: `translate(${x} ${y}) rotate(${rotate}) skewX(${-skew})` }, root);
    const segs = {};
    for (const key of 'abcdefgm') segs[key] = svgEl('polygon', { class: 'seg', points: pts[key] }, g);
    return segs;
  });

  const [cx, cy] = CLOCK.colon;
  const cg = svgEl('g', { transform: `translate(${cx} ${cy}) rotate(${rotate}) skewX(${-skew})` }, root);
  const { h, t } = CLOCK;
  for (const k of [0.30, 0.68]) {
    svgEl('rect', { class: 'seg', x: 0, y: -(h * k + t / 2), width: t, height: t }, cg);
  }
  return { cells, colon: cg };
}

// Лицо часов Sony: «12AM», « 1AM» … « 6AM». Минут и двоеточия нет.
// На время глюка (ночь 5, 3:33) загораются минуты: « 3:33».
export function clockFace(timeSec, glitch = false) {
  if (glitch) return { chars: [' ', '3', '3', '3'], colon: true };
  const hour = Math.min(6, Math.floor(timeSec / 60));
  const s = String(hour === 0 ? 12 : hour).padStart(2, ' ');
  return { chars: [s[0], s[1], 'A', 'M'], colon: false };
}

// ---------- модуль ----------
let root = null;
let offs = [];
let els = {};
let shownText = '';

function el(tag, className, parent) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (parent) parent.appendChild(e);
  return e;
}

function renderClock(state) {
  const face = clockFace(state.time, els.clockGlitch > 0);
  const key = face.chars.join('') + (face.colon ? ':' : '');
  if (key === shownText) return;
  shownText = key;
  face.chars.forEach((ch, i) => {
    const lit = DIGIT_SEGMENTS[ch] || '';
    for (const k of 'abcdefgm') {
      els.cells[i][k].setAttribute('visibility', lit.includes(k) ? 'visible' : 'hidden');
    }
  });
  els.colon.setAttribute('visibility', face.colon ? 'visible' : 'hidden');
}

// Напряжение сцены 0..1: растёт к утру и при перегрузке сети. Только оформление (виньетка).
function updateTension(state) {
  const raw = state.running ? Math.min(1, (state.time / 360) * 0.7 + (state.load >= 5 ? 0.3 : 0)) : 0;
  const v = Math.round(raw * 50) / 50;
  if (v === els.tension) return;
  els.tension = v;
  els.stage.style.setProperty('--tension', String(v));
}

// Слои атмосферы. Всё в процентах сцены, поверх фото ничего не запекается.
function buildFxBelow(stage) {
  el('div', 'fx fx-grade', stage);
  const win = el('div', 'fx fx-window', stage);          // свет с улицы сквозь жалюзи
  els.fxWindow = win;
  el('div', 'fx-window__pass', win);                      // тень «проходит» за окном
  els.fxSpill = el('div', 'fx fx-spill', stage);          // свет мониторов на клавиатуре
  el('div', 'fx fx-vignette', stage);
}

function buildFxAbove(stage) {
  el('div', 'fx fx-led', stage);                          // индикатор веб-камеры сам горит красным
  el('div', 'fx fx-grain', stage);
}

// ---------- мерцание ----------
// На фото нет ламп, поэтому мерцают только реальные источники света:
// фонарь за окном (всегда, редко) и свет мониторов (только при перегрузке сети).
// Серия коротких импульсов с резкими краями. lvl: 1 = норма, меньше = темнее.
const rand = (a, b) => a + Math.random() * (b - a);
const REDUCE = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

function makeFlicker(node, waitFn, planFn) {
  let wait = waitFn();
  let seq = [];
  let acc = 0;
  return (dt, enabled = true) => {
    if (REDUCE || !enabled) {
      if (seq.length) { seq = []; node.style.filter = ''; }
      return;
    }
    if (seq.length) {
      acc += dt;
      while (seq.length && acc >= seq[0].dur) { acc -= seq[0].dur; seq.shift(); }
      node.style.filter = seq.length ? `brightness(${seq[0].lvl.toFixed(2)})` : '';
      if (!seq.length) wait = waitFn();
    } else {
      wait -= dt;
      if (wait <= 0) { seq = planFn(); acc = 0; }
    }
  };
}

function pulses(n, dip, gap) {
  const out = [];
  for (let i = 0; i < n; i++) {
    out.push({ dur: rand(0.03, 0.11), lvl: rand(dip[0], dip[1]) });
    if (i < n - 1) out.push({ dur: rand(gap[0], gap[1]), lvl: rand(0.9, 1) });
  }
  return out;
}

// ---------- отключение при 0% токенов ----------
// Ошибки на мониторах -> глюки -> экран гаснет -> попытка перезагрузки -> не включается. Игрок в темноте.
// Только оформление: длительности фаз считаются из tick, игровой логики здесь нет.
const SHUTDOWN_PHASES = [['error', 3], ['glitch', 2], ['off', 1.5], ['boot', 3.5], ['fail', 2], ['dead', Infinity]];
const SHUTDOWN_DELAY = { left: 0, right: 0.7 };   // правый монитор отстаёт: так живее
const BOOT_STALL_PCT = 72;                         // на каком проценте загрузка «зависает»

function buildShutdown(t) {
  const mons = [];
  for (const [side, node] of [['left', els.monLeft], ['right', els.monRight]]) {
    const root = el('div', 'sd', node);
    root.hidden = true;
    const err = el('div', 'sd-err', root);
    el('div', 'sd-err__title', err).textContent = t(`shutdown.${side}.title`);
    el('div', 'sd-err__text', err).textContent = t(`shutdown.${side}.text`);
    el('div', 'sd-err__code', err).textContent = t('shutdown.code');
    el('div', 'sd-line', root);
    const boot = el('div', 'sd-boot', root);
    el('div', 'sd-boot__title', boot).textContent = t('shutdown.boot');
    const fill = el('i', '', el('div', 'sd-bar', boot));
    el('div', 'sd-boot__fail', boot).textContent = t('shutdown.fail');
    mons.push({ root, node, fill, delay: SHUTDOWN_DELAY[side], phase: null });
  }
  return { mons, t: -1 };
}

function startShutdown() {
  if (els.sd.t < 0) els.sd.t = 0;
}

function resetShutdown() {
  const sd = els.sd;
  if (!sd) return;
  sd.t = -1;
  for (const m of sd.mons) {
    m.phase = null;
    m.root.hidden = true;
    m.root.dataset.phase = '';
    m.node.classList.remove('is-dead');
    m.fill.style.width = '0%';
  }
  els.stage.classList.remove('is-dark');
}

function updateShutdown(dt) {
  const sd = els.sd;
  if (!sd || sd.t < 0) return;
  sd.t += dt;
  for (const m of sd.mons) {
    const local = sd.t - m.delay;
    let phase = null;
    let at = 0;
    if (local >= 0) {
      let rest = local;
      for (const [name, dur] of SHUTDOWN_PHASES) {
        if (rest < dur) { phase = name; at = rest; break; }
        rest -= dur;
      }
    }
    if (phase !== m.phase) {
      m.phase = phase;
      m.root.hidden = phase === null;
      m.root.dataset.phase = phase || '';
      m.node.classList.toggle('is-dead', phase === 'off' || phase === 'dead');
    }
    if (phase === 'boot') {
      // загрузка идёт рывками и застревает
      const pct = BOOT_STALL_PCT * Math.min(1, at / 3.2);
      m.fill.style.width = `${Math.floor(pct / 6) * 6}%`;
    }
  }
  els.stage.classList.toggle('is-dark', sd.mons[0].phase === 'dead');
}

// ---------- скример ----------
// Только оформление: фазы считаются из tick. Вспышка, кадр scream.webp с зумом и дрожанием, резкий чёрный экран,
// затем стартовый экран «Смена провалена». Игровую сторону (конец смены) решает main.js.
// Звук: audio.play('jumpscare') без позиции (в голове игрока); id появится на этапе 8.
const SCARE_FLASH = 0.12;   // секунды
const SCARE_SHOW = 1.4;
const SCARE_BLACK = 0.8;
const SCARE_END = SCARE_FLASH + SCARE_SHOW + SCARE_BLACK;
const SCARE_ZOOM = 0.45;    // насколько кадр вырастает к концу показа
const SCARE_SHAKE = [6, 26];   // дрожание в px, от начала к концу

function buildScare(parent) {
  const rootEl = el('div', 'scare', parent);
  rootEl.hidden = true;
  const img = el('img', 'scare-img', rootEl);
  img.alt = '';
  img.draggable = false;
  el('div', 'scare-tint', rootEl);
  return { root: rootEl, img, t: -1, enemyId: null };
}

function startScare(enemyId) {
  const sc = els.scare;
  if (!sc || sc.t >= 0) return;
  sc.enemyId = enemyId;
  sc.img.src = `assets/img/enemies/${enemyId}/scream.webp`;
  sc.t = 0;
  sc.root.hidden = false;
  sc.root.dataset.phase = 'flash';
  audio.play?.('jumpscare');
}

function resetScare() {
  const sc = els.scare;
  if (!sc) return;
  sc.t = -1;
  sc.root.hidden = true;
  sc.root.dataset.phase = '';
  sc.img.style.transform = '';
}

function updateScare(dt, ctx) {
  const sc = els.scare;
  if (!sc || sc.t < 0) return;
  sc.t += dt;
  if (sc.t >= SCARE_END) {
    resetScare();
    showStart('ui.shiftFailed', ctx);
    return;
  }
  if (sc.t < SCARE_FLASH) {
    sc.root.dataset.phase = 'flash';
  } else if (sc.t < SCARE_FLASH + SCARE_SHOW) {
    sc.root.dataset.phase = 'show';
    const k = (sc.t - SCARE_FLASH) / SCARE_SHOW;
    const scale = REDUCE ? 1.1 : 1 + SCARE_ZOOM * k * k;
    const amp = REDUCE ? 0 : SCARE_SHAKE[0] + (SCARE_SHAKE[1] - SCARE_SHAKE[0]) * k;
    sc.img.style.transform = `translate(${rand(-amp, amp).toFixed(1)}px, ${rand(-amp, amp).toFixed(1)}px) scale(${scale.toFixed(3)})`;
  } else {
    sc.root.dataset.phase = 'black';
  }
}

function showStart(titleKey, ctx) {
  els.startTitle.textContent = ctx.t(titleKey);
  els.start.hidden = false;
}

export function mount(rootEl, ctx) {
  root = rootEl;
  const { state, t, emit, on } = ctx;

  // Фон-подложка для полей по бокам
  const backdrop = el('img', 'backdrop', root);
  backdrop.src = 'assets/img/desk/desk.webp';
  backdrop.alt = '';
  backdrop.draggable = false;

  // Сцена
  els.stage = el('div', 'stage', root);
  const img = el('img', 'desk-photo', els.stage);
  img.src = 'assets/img/desk/desk.webp';
  img.alt = '';
  img.draggable = false;

  buildFxBelow(els.stage);

  els.monLeft = el('div', 'mon', els.stage);
  els.monLeft.id = 'monitor-left';
  els.monRight = el('div', 'mon', els.stage);
  els.monRight.id = 'monitor-right';
  els.sd = buildShutdown(t);
  layoutMonitors();
  if (typeof ResizeObserver !== 'undefined') {
    els.resizeObserver = new ResizeObserver(layoutMonitors);
    els.resizeObserver.observe(els.stage);
  } else {
    window.addEventListener('resize', layoutMonitors);
  }

  const clock = buildClock(els.stage);
  els.cells = clock.cells;
  els.colon = clock.colon;
  els.clockGlitch = 0;
  buildFxAbove(els.stage);
  renderClock(state);

  // фонарь за окном: редко и неровно, к утру чаще
  els.flickWin = makeFlicker(els.fxWindow,
    () => rand(8, 35) * (1 - 0.5 * (els.tension || 0)),
    () => pulses(2 + Math.floor(Math.random() * 4), [0.15, 0.6], [0.04, 0.25]));
  // свет мониторов: только при перегрузке сети, часто и коротко
  els.flickSpill = makeFlicker(els.fxSpill,
    () => rand(0.4, 1.8),
    () => pulses(1 + Math.floor(Math.random() * 3), [0.3, 0.7], [0.03, 0.12]));

  els.scare = buildScare(root);

  // Стартовый экран
  els.start = el('div', 'start-screen', root);
  els.startTitle = el('h1', 'start-title', els.start);
  els.startHint = el('p', 'start-hint', els.start);
  els.startHint.textContent = t('ui.headphones');
  els.startBtn = el('button', 'start-btn', els.start);
  els.startBtn.type = 'button';
  els.startBtn.textContent = t('ui.startShift');
  els.startTitle.textContent = t('ui.title');

  // pointerup от касания — это жест, после которого браузер разрешает звук.
  els.startBtn.addEventListener('pointerup', (e) => {
    if (e.button > 0) return;
    emit('intent:startShift');
  });

  // Подсказка поворота (показывается CSS-ом в портретной ориентации)
  els.rotate = el('div', 'rotate-hint', root);
  els.rotate.textContent = t('ui.rotateHint');

  const syncCam = () => els.stage.classList.toggle('is-cam', state.camera !== null);
  offs = [
    on('tick', ({ dt }) => {
      if (els.clockGlitch > 0) els.clockGlitch = Math.max(0, els.clockGlitch - dt);
      renderClock(state);
      updateTension(state);
      els.flickWin(dt, state.running);
      els.flickSpill(dt, state.running && state.tokens > 0 && state.load >= 5);
      // читаем состояние каждый кадр: так сработает при любом способе обнуления (в т.ч. из отладки)
      if (state.running && state.tokens <= 0) startShutdown();
      else if (state.tokens > 0 && els.sd.t >= 0) resetShutdown();
      updateShutdown(dt);
      updateScare(dt, ctx);
    }),
    on('jumpscare', ({ enemyId }) => startScare(enemyId)),
    on('glitch', ({ type }) => {
      if (type !== 'clock333') return;
      els.clockGlitch = CLOCK_GLITCH_SEC;
      renderClock(state);
    }),
    on('camera:open', syncCam),
    on('camera:close', syncCam),
    on('night:start', () => {
      resetShutdown();
      resetScare();
      shownText = '';
      els.clockGlitch = 0;
      renderClock(state);
      syncCam();
      els.start.hidden = true;
    }),
    // Временно: полноценный экран итога появится на этапе 10.
    // После скримера (failed) стартовый экран покажет updateScare, когда кадр отыграет.
    on('night:end', (p) => { if (!p?.failed) showStart('ui.shiftOver', ctx); }),
  ];
}

export function unmount() {
  els.resizeObserver?.disconnect();
  offs.forEach((off) => off());
  offs = [];
  if (root) root.replaceChildren();
  root = null;
  els = {};
  shownText = '';
}